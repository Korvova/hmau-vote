document.addEventListener('DOMContentLoaded', function () {


    //  JS slide
    let slideUp = (target, duration = 500) => {
        target.style.transitionProperty = 'height, margin, padding';
        target.style.transitionDuration = duration + 'ms';
        target.style.boxSizing = 'border-box';
        target.style.height = target.offsetHeight + 'px';
        target.offsetHeight;
        target.style.overflow = 'hidden';
        target.style.height = 0;
        target.style.paddingTop = 0;
        target.style.paddingBottom = 0;
        target.style.marginTop = 0;
        target.style.marginBottom = 0;
        window.setTimeout(() => {
            target.style.display = 'none';
            target.style.removeProperty('height');
            target.style.removeProperty('padding-top');
            target.style.removeProperty('padding-bottom');
            target.style.removeProperty('margin-top');
            target.style.removeProperty('margin-bottom');
            target.style.removeProperty('overflow');
            target.style.removeProperty('transition-duration');
            target.style.removeProperty('transition-property');
            //alert("!");
        }, duration);
    }

    let slideDown = (target, duration = 500) => {
        target.style.removeProperty('display');
        let display = window.getComputedStyle(target).display;

        if (display === 'none')
            display = 'block';

        target.style.display = display;
        let height = target.offsetHeight;
        target.style.overflow = 'hidden';
        target.style.height = 0;
        target.style.paddingTop = 0;
        target.style.paddingBottom = 0;
        target.style.marginTop = 0;
        target.style.marginBottom = 0;
        target.offsetHeight;
        target.style.boxSizing = 'border-box';
        target.style.transitionProperty = "height, margin, padding";
        target.style.transitionDuration = duration + 'ms';
        target.style.height = height + 'px';
        target.style.removeProperty('padding-top');
        target.style.removeProperty('padding-bottom');
        target.style.removeProperty('margin-top');
        target.style.removeProperty('margin-bottom');
        window.setTimeout(() => {
            target.style.removeProperty('height');
            target.style.removeProperty('overflow');
            target.style.removeProperty('transition-duration');
            target.style.removeProperty('transition-property');
        }, duration);
    }
    var slideToggle = (target, duration = 500) => {
        if (window.getComputedStyle(target).display === 'none') {
            return slideDown(target, duration);
        } else {
            return slideUp(target, duration);
        }
    }

    // slideUp(document.getElementById("target"), 200);
    // slideDown(document.getElementById("target"), 200);
    // slideToggle(document.getElementById("target"), 200);


    //  header__menu
    const menuChildren = document.querySelectorAll('.header__menu .menu-children');

    menuChildren.forEach(function (item) {
        const link = item.querySelector('.menu-children > a');
        const subMenu = item.querySelector('.sub-menu');

        link.addEventListener('click', function (e) {
            e.preventDefault();
            slideToggle(subMenu, 200);
        });
    });


    // table user
    const userButtons = document.querySelectorAll('.user__nav .user__button');

    userButtons?.forEach(button => {
        button.addEventListener('click', function (e) {
            e.stopPropagation();

            const currentList = this.nextElementSibling;
            const isActive = this.classList.contains('active');

            document.querySelectorAll('.nav__links').forEach(ul => {
                if (ul !== currentList) {
                    ul.style.display = 'none';
                }
            });

            userButtons.forEach(btn => {
                if (btn !== this) {
                    btn.classList.remove('active');
                }
            });

            if (!isActive) {
                this.classList.add('active');
                currentList.style.display = 'block';
                slideDown(currentList, 200);
            } else {
                this.classList.remove('active');
                slideUp(currentList, 200);
            }
        });
    });


    // custom date/time
    flatpickr(".datetime", {
        enableTime: true,
        dateFormat: "Y-m-d H:i",
        locale: "ru",
        defaultDate: new Date() 
    });



});